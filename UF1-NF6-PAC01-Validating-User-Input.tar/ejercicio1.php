<html>
 <head>
  <title>Formulario de email</title>
 </head>
 <body>
  <form action="ejercicio2.php" method="post">
   <table>
    <tr>
     <td>Email</td>
     <td><input type="text" name="email" /></td>
    </tr>
     <td colspan="2" style="text-align: center;">
      <input type="submit" name="submit" value="Submit" /></td>
    </tr>
   </table>
  </form>
 </body>
</html>