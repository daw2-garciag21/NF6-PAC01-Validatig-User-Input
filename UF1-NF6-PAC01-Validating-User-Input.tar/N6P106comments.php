<html>
    <head>
    <title>Documento</title>
    <body>
        <ol>
            <li>He aprendido a revisar los documentos mucho para encontrar el error</li>
            <li>He recordardo los formularios</li>
            <li>He aprendido como se usaba la variable post</li>
            <li>He aprendido a como hacer un formulario que te diga si un correo es invalido o no</li>
            <li>He aprendido a que se puede usar el break en php</li>
            <li>He aprendido a poner unas variables más dentro de una tabla</li>
            <li>He aprendido a hacer el edit</li>
            <li>He aprendido a como solucionar el add</li>
            <li>he aprendido algo más de bucles</li>
            <li>He recordado un poco de base de datos</li>
        </ol>
        <p>Documento 7 y la explicación un 7</p>
        <p>10</p>
        <p>He estado mucho tiempo con el ejercicio 1 por eso creo que me merezco un 10 de nota. He estado sufriendo en silencio con esta práctica y me ha costado pues mucho esfuerzo. El documento está bien pero es dificil ese ejercicio</p>
    </body>
    </head>
</html>